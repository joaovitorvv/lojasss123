import { Category } from '../types';

export const categories: Category[] = [
  {
    id: '1',
    name: 'Audio',
    description: 'Premium headphones, earbuds & speakers',
    image: 'https://images.pexels.com/photos/577769/pexels-photo-577769.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: '2',
    name: 'Wearables',
    description: 'Smart watches & fitness trackers',
    image: 'https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: '3',
    name: 'Smart Home',
    description: 'Connected devices for modern living',
    image: 'https://images.pexels.com/photos/373691/pexels-photo-373691.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: '4',
    name: 'Computers',
    description: 'Laptops, tablets & accessories',
    image: 'https://images.pexels.com/photos/18105/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: '5',
    name: 'Mobility',
    description: 'Electric scooters & personal transport',
    image: 'https://images.pexels.com/photos/6894528/pexels-photo-6894528.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: '6',
    name: 'Drones',
    description: 'Capture the world from above',
    image: 'https://images.pexels.com/photos/336232/pexels-photo-336232.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  }
];

export const getFeaturedCategories = () => categories.slice(0, 3);
export const getCategoryById = (id: string) => categories.find(c => c.id === id);
export const getCategoryByName = (name: string) => 
  categories.find(c => c.name.toLowerCase() === name.toLowerCase());