import { Product } from '../types';

export const products: Product[] = [
  {
    id: '1',
    name: 'Wireless Earbuds Pro',
    description: 'Experience crystal clear audio with our advanced noise-cancelling wireless earbuds. Perfect for workouts, commuting, or just relaxing with your favorite music.',
    price: 129.99,
    images: [
      'https://images.pexels.com/photos/3780681/pexels-photo-3780681.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/3945667/pexels-photo-3945667.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'audio',
    isFeatured: true,
    isNew: true,
    stock: 15,
    rating: 4.8,
    specs: {
      'Battery Life': 'Up to 24 hours',
      'Connectivity': 'Bluetooth 5.2',
      'Water Resistance': 'IPX4',
      'Charging': 'USB-C and Wireless'
    }
  },
  {
    id: '2',
    name: 'Smart Watch Series X',
    description: 'Track your fitness, monitor your health, and stay connected with our latest smartwatch. Features a bright OLED display and up to 7 days of battery life.',
    price: 249.99,
    images: [
      'https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/9386663/pexels-photo-9386663.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'wearables',
    isFeatured: true,
    stock: 10,
    rating: 4.5,
    specs: {
      'Display': '1.4" AMOLED',
      'Battery Life': 'Up to 7 days',
      'Water Resistance': '5 ATM',
      'Sensors': 'Heart rate, SpO2, Accelerometer'
    }
  },
  {
    id: '3',
    name: 'Ultra HD 4K Drone',
    description: 'Capture breathtaking aerial footage with our 4K drone. Features intelligent flight modes, obstacle avoidance, and 30 minutes of flight time.',
    price: 799.99,
    images: [
      'https://images.pexels.com/photos/336232/pexels-photo-336232.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/1327400/pexels-photo-1327400.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'drones',
    isNew: true,
    stock: 5,
    rating: 4.7,
    specs: {
      'Camera': '4K @ 60fps',
      'Flight Time': '30 minutes',
      'Range': '8 km',
      'Features': 'GPS, Return-to-Home, Obstacle Avoidance'
    }
  },
  {
    id: '4',
    name: 'Portable Power Station',
    description: 'Keep your devices powered on the go with this high-capacity portable power station. Perfect for camping, emergencies, or anywhere you need reliable power.',
    price: 349.99,
    images: [
      'https://images.pexels.com/photos/3945664/pexels-photo-3945664.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/1526402/pexels-photo-1526402.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'accessories',
    discountPercentage: 15,
    stock: 20,
    rating: 4.6,
    specs: {
      'Capacity': '500Wh',
      'Ports': '2x AC, 2x USB-A, 2x USB-C, 1x DC',
      'Weight': '14 lbs',
      'Charging': 'AC, Solar'
    }
  },
  {
    id: '5',
    name: 'Smart Home Security Camera',
    description: 'Keep an eye on your home with our wireless security camera featuring AI person detection, night vision, and two-way audio.',
    price: 129.99,
    images: [
      'https://images.pexels.com/photos/373691/pexels-photo-373691.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/207589/pexels-photo-207589.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'smart home',
    isFeatured: true,
    stock: 25,
    rating: 4.4,
    specs: {
      'Resolution': '2K QHD',
      'Field of View': '130°',
      'Storage': 'Cloud and Local SD Card',
      'Features': 'AI Detection, Night Vision, Two-way Audio'
    }
  },
  {
    id: '6',
    name: 'Foldable Electric Scooter',
    description: 'Commute in style with our lightweight electric scooter. Features a powerful motor, long-range battery, and foldable design for easy storage.',
    price: 599.99,
    images: [
      'https://images.pexels.com/photos/6894528/pexels-photo-6894528.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/5490202/pexels-photo-5490202.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'mobility',
    stock: 8,
    rating: 4.3,
    specs: {
      'Range': 'Up to 25 miles',
      'Top Speed': '18 mph',
      'Weight Capacity': '220 lbs',
      'Features': 'Disc Brake, LED Lights, App Connectivity'
    }
  },
  {
    id: '7',
    name: 'Noise Cancelling Headphones',
    description: 'Immerse yourself in your music with our premium over-ear headphones featuring active noise cancellation and high-resolution audio.',
    price: 199.99,
    images: [
      'https://images.pexels.com/photos/577769/pexels-photo-577769.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/3394666/pexels-photo-3394666.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'audio',
    discountPercentage: 10,
    stock: 12,
    rating: 4.9,
    specs: {
      'Battery Life': 'Up to 30 hours',
      'Connectivity': 'Bluetooth 5.0, 3.5mm',
      'Noise Cancellation': 'Adaptive ANC',
      'Features': 'Touch Controls, Voice Assistant'
    }
  },
  {
    id: '8',
    name: 'Ultra-Slim Laptop',
    description: 'Powerful performance in an incredibly thin and light design. Features a stunning display, all-day battery life, and the latest processors.',
    price: 1299.99,
    images: [
      'https://images.pexels.com/photos/18105/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/129208/pexels-photo-129208.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'computers',
    isNew: true,
    isFeatured: true,
    stock: 7,
    rating: 4.8,
    specs: {
      'Processor': 'Intel Core i7',
      'RAM': '16GB',
      'Storage': '512GB SSD',
      'Display': '14" 4K OLED'
    }
  }
];

// Helper functions to filter products
export const getFeaturedProducts = () => products.filter(p => p.isFeatured);
export const getNewArrivals = () => products.filter(p => p.isNew);
export const getDiscountedProducts = () => products.filter(p => p.discountPercentage && p.discountPercentage > 0);
export const getProductsByCategory = (category: string) => products.filter(p => p.category === category);
export const getProductById = (id: string) => products.find(p => p.id === id);