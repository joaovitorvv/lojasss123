import React, { useState } from 'react';
import { Send } from 'lucide-react';

const Newsletter: React.FC = () => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setEmail('');
    }
  };

  return (
    <section className="py-16 bg-gradient-to-r from-blue-500 to-purple-600 text-white">
      <div className="container-custom">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-display font-bold mb-4">
            Fique por dentro das novidades
          </h2>
          <p className="text-gray-100 mb-8">
            Inscreva-se em nossa newsletter e seja o primeiro a saber sobre novos produtos, 
            ofertas exclusivas e eventos futuros.
          </p>

          {subscribed ? (
            <div className="bg-white/10 rounded-lg p-6 backdrop-blur-sm">
              <p className="text-xl font-medium">Obrigado por se inscrever!</p>
              <p className="mt-2">Você receberá nossa próxima newsletter em seu e-mail.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
              <input
                type="email"
                placeholder="Seu endereço de e-mail"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="flex-grow px-4 py-3 rounded-full text-gray-900 focus:outline-none focus:ring-2 focus:ring-white/50"
                required
              />
              <button 
                type="submit"
                className="btn-secondary rounded-full flex items-center justify-center px-6 py-3"
              >
                Inscrever-se
                <Send size={16} className="ml-2" />
              </button>
            </form>
          )}
        </div>
      </div>
    </section>
  );
};

export default Newsletter;