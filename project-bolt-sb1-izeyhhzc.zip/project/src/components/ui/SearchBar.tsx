import React, { useState } from 'react';
import { Search, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface SearchBarProps {
  onSearch?: () => void;
}

const SearchBar: React.FC<SearchBarProps> = ({ onSearch }) => {
  const [query, setQuery] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      navigate(`/products?search=${encodeURIComponent(query.trim())}`);
      if (onSearch) onSearch();
      setQuery('');
    }
  };

  const clearSearch = () => {
    setQuery('');
  };

  return (
    <form onSubmit={handleSubmit} className="relative w-full max-w-3xl mx-auto">
      <div className="relative">
        <div className="absolute inset-y-0 left-0 flex items-center pl-4 pointer-events-none">
          <Search className="text-gray-400" size={20} />
        </div>
        <input
          type="search"
          className="w-full pl-12 pr-12 py-3 bg-gray-100 border-none rounded-full focus:ring-2 focus:ring-blue-500 focus:bg-white transition-colors text-base"
          placeholder="O que você está procurando?"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        {query && (
          <button 
            type="button"
            className="absolute inset-y-0 right-14 flex items-center pr-3"
            onClick={clearSearch}
          >
            <X className="text-gray-400 hover:text-gray-600" size={18} />
          </button>
        )}
        <button 
          type="submit"
          className="absolute inset-y-0 right-0 flex items-center pr-4"
        >
          <span className="text-sm font-medium text-blue-600 hover:text-blue-800">Buscar</span>
        </button>
      </div>
    </form>
  );
};

export default SearchBar;