import React, { useState, useEffect } from 'react';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

interface HeroBannerProps {
  videoUrl: string;
  title: string;
  subtitle: string;
  ctaText: string;
  ctaLink: string;
}

const HeroBanner: React.FC<HeroBannerProps> = ({ 
  videoUrl, 
  title, 
  subtitle, 
  ctaText, 
  ctaLink 
}) => {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoaded(true);
    }, 500);
    
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="relative h-[70vh] md:h-[85vh] w-full overflow-hidden">
      {/* Video Background */}
      <div className="absolute inset-0 w-full h-full bg-black">
        <video
          autoPlay
          muted
          loop
          playsInline
          className={`object-cover w-full h-full opacity-70 transition-opacity duration-1000 ${
            isLoaded ? 'opacity-70' : 'opacity-0'
          }`}
          onCanPlay={() => setIsLoaded(true)}
          poster="https://images.pexels.com/photos/2356059/pexels-photo-2356059.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
        >
          <source src="https://player.vimeo.com/progressive_redirect/playback/530215547/rendition/720p/file.mp4?loc=external&signature=c7c3486f2c14fc8a27f47ec83c8b406ff3e7b2f7c9f00b2e88c2cd612d8aae90" type="video/mp4" />
          Seu navegador não suporta vídeos.
        </video>
      </div>

      {/* Content Overlay */}
      <div className="relative z-10 h-full container-custom flex flex-col justify-center items-start">
        <div className={`max-w-xl transition-all duration-1000 ${
          isLoaded ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'
        }`}>
          <h1 className="text-white text-4xl md:text-5xl lg:text-6xl font-display font-bold mb-4">
            {title}
          </h1>
          <p className="text-gray-200 text-lg md:text-xl mb-8">
            {subtitle}
          </p>
          <Link 
            to={ctaLink}
            className="btn-primary group"
          >
            {ctaText}
            <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
          </Link>
        </div>
      </div>

      {/* Gradient Overlay */}
      <div className="absolute bottom-0 left-0 right-0 h-1/3 bg-gradient-to-t from-black/50 to-transparent"></div>
    </div>
  );
};

export default HeroBanner;