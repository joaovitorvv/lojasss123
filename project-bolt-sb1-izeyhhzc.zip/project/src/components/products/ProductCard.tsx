import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingCart, Heart } from 'lucide-react';
import { Product } from '../../types';
import { useCart } from '../../context/CartContext';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { id, name, price, images, category, isFeatured, isNew, discountPercentage } = product;
  const { addToCart } = useCart();
  
  const discountedPrice = discountPercentage 
    ? price - (price * (discountPercentage / 100)) 
    : null;

  return (
    <div className="product-card group">
      {/* Product Image */}
      <Link to={`/products/${id}`} className="block relative overflow-hidden">
        <div className="aspect-w-1 aspect-h-1 w-full bg-gray-200">
          <img 
            src={images[0]} 
            alt={name}
            className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
          />
        </div>
        
        {/* Product Badges */}
        <div className="absolute top-2 left-2 flex flex-col gap-2">
          {isNew && (
            <span className="bg-black text-white text-xs font-medium px-2 py-1 rounded">
              NEW
            </span>
          )}
          {isFeatured && (
            <span className="bg-gradient-to-r from-blue-500 to-purple-600 text-white text-xs font-medium px-2 py-1 rounded">
              FEATURED
            </span>
          )}
          {discountPercentage > 0 && (
            <span className="bg-red-600 text-white text-xs font-medium px-2 py-1 rounded">
              {discountPercentage}% OFF
            </span>
          )}
        </div>

        {/* Quick Actions */}
        <div className="absolute -bottom-10 group-hover:bottom-2 left-0 right-0 flex justify-center transition-all duration-300 px-2">
          <div className="flex space-x-2">
            <button 
              onClick={(e) => {
                e.preventDefault();
                addToCart(product);
              }}
              className="p-2 bg-white rounded-full shadow hover:shadow-md transition-shadow"
              aria-label="Add to cart"
            >
              <ShoppingCart size={18} className="text-black" />
            </button>
            <button 
              onClick={(e) => e.preventDefault()}
              className="p-2 bg-white rounded-full shadow hover:shadow-md transition-shadow"
              aria-label="Add to wishlist"
            >
              <Heart size={18} className="text-black" />
            </button>
          </div>
        </div>
      </Link>

      {/* Product Info */}
      <div className="p-4">
        <Link to={`/products/${id}`} className="block">
          <h3 className="text-sm font-medium text-gray-900 hover:text-blue-600 transition-colors">
            {name}
          </h3>
          <p className="mt-1 text-xs text-gray-500 capitalize">{category}</p>
          <div className="mt-2 flex items-center">
            {discountedPrice ? (
              <>
                <span className="text-sm font-medium text-gray-900">${discountedPrice.toFixed(2)}</span>
                <span className="ml-2 text-xs text-gray-500 line-through">${price.toFixed(2)}</span>
              </>
            ) : (
              <span className="text-sm font-medium text-gray-900">${price.toFixed(2)}</span>
            )}
          </div>
        </Link>
      </div>
    </div>
  );
};

export default ProductCard;