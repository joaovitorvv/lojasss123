import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ShoppingCart, Search, Menu, X } from 'lucide-react';
import SearchBar from '../ui/SearchBar';
import CartWidget from '../cart/CartWidget';
import { useCart } from '../../context/CartContext';

const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();
  const { totalItems } = useCart();

  const navItems = [
    { name: 'Início', path: '/' },
    { name: 'Loja', path: '/products' },
    { name: 'Novidades', path: '/products?category=new' },
    { name: 'Destaques', path: '/products?category=featured' },
    { name: 'Promoções', path: '/products?category=sale' },
  ];

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location]);

  return (
    <header className="fixed top-0 left-0 right-0 z-50">
      {/* Top Search Bar */}
      <div className="bg-white border-b border-gray-200 py-2">
        <div className="container-custom">
          <SearchBar />
        </div>
      </div>

      {/* Floating Menu */}
      <div 
        className={`bg-white/95 backdrop-blur-sm shadow-lg transition-all duration-300 py-4 mt-4 mx-4 rounded-xl ${
          isScrolled ? 'transform translate-y-0' : 'transform translate-y-0'
        }`}
      >
        <div className="container-custom">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <Link to="/" className="relative z-10">
              <h1 className="text-2xl font-display font-bold text-black">DAYVA</h1>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center justify-center space-x-8">
              {navItems.map((item) => (
                <Link 
                  key={item.name} 
                  to={item.path}
                  className={`text-sm font-medium transition-colors ${
                    location.pathname === item.path ? 'text-black' : 'text-gray-600 hover:text-black'
                  }`}
                >
                  {item.name}
                </Link>
              ))}
            </nav>

            {/* Right Actions */}
            <div className="flex items-center space-x-4">
              {/* Cart */}
              <Link to="/cart" className="text-black hover:text-gray-700 transition-colors relative">
                <ShoppingCart size={20} />
                {totalItems > 0 && (
                  <span className="absolute -top-2 -right-2 w-5 h-5 flex items-center justify-center rounded-full bg-gradient-to-r from-blue-500 to-purple-600 text-white text-xs">
                    {totalItems}
                  </span>
                )}
              </Link>

              {/* Mobile Menu Toggle */}
              <button 
                className="md:hidden text-black hover:text-gray-700 transition-colors"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                aria-label={mobileMenuOpen ? 'Fechar menu' : 'Abrir menu'}
              >
                {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <div 
        className={`fixed inset-0 bg-white z-40 transition-transform duration-300 transform ${
          mobileMenuOpen ? 'translate-x-0' : 'translate-x-full'
        } md:hidden pt-20`}
      >
        <div className="container-custom">
          <nav className="flex flex-col space-y-6 py-8">
            {navItems.map((item) => (
              <Link 
                key={item.name} 
                to={item.path}
                className={`text-lg font-medium transition-colors ${
                  location.pathname === item.path ? 'text-black' : 'text-gray-600 hover:text-black'
                }`}
                onClick={() => setMobileMenuOpen(false)}
              >
                {item.name}
              </Link>
            ))}
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;