import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ShoppingCart, Heart, Star, Truck, Shield, ArrowLeft } from 'lucide-react';
import ProductGrid from '../components/products/ProductGrid';
import { getProductById, getFeaturedProducts } from '../data/products';
import { useCart } from '../context/CartContext';

const ProductDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  
  const product = id ? getProductById(id) : null;
  const [quantity, setQuantity] = useState(1);
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [relatedProducts, setRelatedProducts] = useState(getFeaturedProducts().slice(0, 4));
  
  useEffect(() => {
    // Scroll to top when product changes
    window.scrollTo(0, 0);
    
    // Reset state when product changes
    setQuantity(1);
    setActiveImageIndex(0);
  }, [id]);
  
  if (!product) {
    return (
      <div className="container-custom py-24 text-center">
        <h2 className="text-2xl font-medium mb-4">Product not found</h2>
        <p className="text-gray-600 mb-6">
          The product you're looking for doesn't exist or has been removed.
        </p>
        <button
          onClick={() => navigate('/products')}
          className="btn-primary"
        >
          Back to Products
        </button>
      </div>
    );
  }
  
  const handleAddToCart = () => {
    addToCart(product, quantity);
  };
  
  const decreaseQuantity = () => {
    setQuantity((prev) => Math.max(1, prev - 1));
  };
  
  const increaseQuantity = () => {
    setQuantity((prev) => Math.min(product.stock, prev + 1));
  };
  
  return (
    <div className="container-custom py-12 pt-24 md:pt-32">
      <div className="mb-8">
        <button
          onClick={() => navigate(-1)}
          className="inline-flex items-center text-gray-600 hover:text-black transition-colors"
        >
          <ArrowLeft size={16} className="mr-1" /> Back
        </button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        {/* Product Images */}
        <div>
          <div className="aspect-w-1 aspect-h-1 bg-gray-100 rounded-lg overflow-hidden mb-4">
            <img
              src={product.images[activeImageIndex]}
              alt={product.name}
              className="w-full h-full object-cover object-center"
            />
          </div>
          
          {product.images.length > 1 && (
            <div className="grid grid-cols-4 gap-2">
              {product.images.map((image, index) => (
                <button
                  key={index}
                  onClick={() => setActiveImageIndex(index)}
                  className={`rounded-md overflow-hidden border-2 ${
                    activeImageIndex === index
                      ? 'border-blue-500'
                      : 'border-transparent'
                  }`}
                >
                  <img
                    src={image}
                    alt={`${product.name} thumbnail ${index}`}
                    className="w-full h-full object-cover object-center"
                  />
                </button>
              ))}
            </div>
          )}
        </div>
        
        {/* Product Details */}
        <div className="flex flex-col">
          {/* Product badges */}
          <div className="flex space-x-2 mb-3">
            {product.isNew && (
              <span className="bg-black text-white text-xs font-medium px-2 py-1 rounded">
                NEW
              </span>
            )}
            {product.isFeatured && (
              <span className="bg-gradient-to-r from-blue-500 to-purple-600 text-white text-xs font-medium px-2 py-1 rounded">
                FEATURED
              </span>
            )}
            {product.discountPercentage && product.discountPercentage > 0 && (
              <span className="bg-red-600 text-white text-xs font-medium px-2 py-1 rounded">
                {product.discountPercentage}% OFF
              </span>
            )}
          </div>
          
          {/* Name and category */}
          <h1 className="text-3xl md:text-4xl font-display font-bold mb-2">
            {product.name}
          </h1>
          <p className="text-gray-500 text-sm mb-4 capitalize">{product.category}</p>
          
          {/* Price */}
          <div className="mb-6">
            {product.discountPercentage && product.discountPercentage > 0 ? (
              <div className="flex items-center">
                <span className="text-2xl font-medium">
                  ${(product.price - (product.price * (product.discountPercentage / 100))).toFixed(2)}
                </span>
                <span className="ml-2 text-gray-500 line-through text-lg">
                  ${product.price.toFixed(2)}
                </span>
              </div>
            ) : (
              <span className="text-2xl font-medium">
                ${product.price.toFixed(2)}
              </span>
            )}
          </div>
          
          {/* Rating */}
          {product.rating && (
            <div className="flex items-center mb-6">
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    size={18}
                    className={`${
                      i < Math.floor(product.rating!)
                        ? 'text-yellow-400 fill-yellow-400'
                        : 'text-gray-300'
                    }`}
                  />
                ))}
              </div>
              <span className="ml-2 text-sm text-gray-600">
                {product.rating} out of 5
              </span>
            </div>
          )}
          
          {/* Description */}
          <p className="text-gray-700 mb-8">{product.description}</p>
          
          {/* Add to cart */}
          <div className="flex flex-col space-y-4 sm:flex-row sm:space-y-0 sm:space-x-4 mb-8">
            <div className="flex border border-gray-300 rounded-md">
              <button
                onClick={decreaseQuantity}
                disabled={quantity <= 1}
                className="px-4 py-2 text-lg font-medium disabled:text-gray-300"
              >
                -
              </button>
              <div className="flex items-center justify-center min-w-[3rem] px-2 border-x border-gray-300">
                <span className="text-center font-medium">{quantity}</span>
              </div>
              <button
                onClick={increaseQuantity}
                disabled={quantity >= product.stock}
                className="px-4 py-2 text-lg font-medium disabled:text-gray-300"
              >
                +
              </button>
            </div>
            
            <button
              onClick={handleAddToCart}
              disabled={product.stock === 0}
              className="btn-primary flex-1 sm:flex-none sm:min-w-[200px]"
            >
              <ShoppingCart size={18} className="mr-2" />
              {product.stock > 0 ? 'Add to Cart' : 'Out of Stock'}
            </button>
            
            <button className="btn-outline flex-1 sm:flex-none">
              <Heart size={18} className="mr-2" />
              Wishlist
            </button>
          </div>
          
          {/* Stock */}
          <div className="mb-6">
            <p className="text-sm text-gray-700">
              Availability:{' '}
              <span
                className={`font-medium ${
                  product.stock > 0 ? 'text-green-600' : 'text-red-600'
                }`}
              >
                {product.stock > 0
                  ? `In Stock (${product.stock} available)`
                  : 'Out of Stock'}
              </span>
            </p>
          </div>
          
          {/* Additional info */}
          <div className="border-t border-gray-200 pt-6 space-y-4">
            <div className="flex items-center">
              <Truck size={20} className="text-gray-600 mr-2" />
              <p className="text-sm text-gray-700">
                Free shipping on orders over $50
              </p>
            </div>
            <div className="flex items-center">
              <Shield size={20} className="text-gray-600 mr-2" />
              <p className="text-sm text-gray-700">
                2-year warranty included
              </p>
            </div>
          </div>
          
          {/* Specs */}
          {product.specs && Object.keys(product.specs).length > 0 && (
            <div className="border-t border-gray-200 pt-6 mt-6">
              <h3 className="text-lg font-medium mb-4">Specifications</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-2 gap-x-4">
                {Object.entries(product.specs).map(([key, value]) => (
                  <div key={key} className="flex justify-between">
                    <span className="text-gray-600">{key}</span>
                    <span className="font-medium">{value}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* Related Products */}
      <div className="mt-16">
        <ProductGrid
          products={relatedProducts.filter(p => p.id !== product.id)}
          title="You might also like"
          subtitle="Products similar to this one"
        />
      </div>
    </div>
  );
};

export default ProductDetailPage;