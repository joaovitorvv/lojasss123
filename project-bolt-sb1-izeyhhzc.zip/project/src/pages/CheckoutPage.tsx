import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CreditCard, Shield, ChevronRight } from 'lucide-react';
import { useCart } from '../context/CartContext';

interface ShippingFormData {
  firstName: string;
  lastName: string;
  email: string;
  address1: string;
  address2: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  phone: string;
}

interface PaymentFormData {
  cardName: string;
  cardNumber: string;
  expDate: string;
  cvv: string;
}

const CheckoutPage: React.FC = () => {
  const navigate = useNavigate();
  const { cart, totalPrice, clearCart } = useCart();
  const [step, setStep] = useState<'shipping' | 'payment' | 'confirmation'>('shipping');
  
  const [shippingFormData, setShippingFormData] = useState<ShippingFormData>({
    firstName: '',
    lastName: '',
    email: '',
    address1: '',
    address2: '',
    city: '',
    state: '',
    postalCode: '',
    country: 'US',
    phone: '',
  });
  
  const [paymentFormData, setPaymentFormData] = useState<PaymentFormData>({
    cardName: '',
    cardNumber: '',
    expDate: '',
    cvv: '',
  });
  
  const handleShippingChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setShippingFormData((prev) => ({ ...prev, [name]: value }));
  };
  
  const handlePaymentChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setPaymentFormData((prev) => ({ ...prev, [name]: value }));
  };
  
  const handleShippingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('payment');
    window.scrollTo(0, 0);
  };
  
  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('confirmation');
    window.scrollTo(0, 0);
    
    // In a real app, this is where you would process the payment
    // and create the order in your database
  };
  
  const handlePlaceOrder = () => {
    // In a real app, this would finalize the order
    clearCart();
    navigate('/');
  };
  
  const isShippingFormValid = () => {
    const requiredFields = ['firstName', 'lastName', 'email', 'address1', 'city', 'state', 'postalCode', 'country', 'phone'];
    return requiredFields.every(field => Boolean(shippingFormData[field as keyof ShippingFormData]));
  };
  
  const isPaymentFormValid = () => {
    return Object.values(paymentFormData).every(Boolean);
  };
  
  if (cart.length === 0 && step !== 'confirmation') {
    navigate('/cart');
    return null;
  }
  
  return (
    <div className="container-custom py-12 pt-24 md:pt-32">
      {/* Checkout Steps */}
      <div className="mb-8">
        <div className="flex items-center justify-center">
          <div className={`flex flex-col items-center ${step === 'shipping' ? 'text-blue-600' : 'text-gray-900'}`}>
            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
              step === 'shipping' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-700'
            }`}>
              1
            </div>
            <span className="mt-2 text-sm">Shipping</span>
          </div>
          <div className={`w-24 h-1 mx-2 ${
            step === 'shipping' ? 'bg-gray-200' : 'bg-blue-600'
          }`}></div>
          <div className={`flex flex-col items-center ${step === 'payment' ? 'text-blue-600' : 'text-gray-900'}`}>
            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
              step === 'payment' ? 'bg-blue-600 text-white' : step === 'confirmation' ? 'bg-gray-200 text-gray-700' : 'bg-gray-200 text-gray-700'
            }`}>
              2
            </div>
            <span className="mt-2 text-sm">Payment</span>
          </div>
          <div className={`w-24 h-1 mx-2 ${
            step === 'confirmation' ? 'bg-blue-600' : 'bg-gray-200'
          }`}></div>
          <div className={`flex flex-col items-center ${step === 'confirmation' ? 'text-blue-600' : 'text-gray-900'}`}>
            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
              step === 'confirmation' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-700'
            }`}>
              3
            </div>
            <span className="mt-2 text-sm">Confirmation</span>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-2">
          {step === 'shipping' && (
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-xl font-medium mb-6">Shipping Information</h2>
              
              <form onSubmit={handleShippingSubmit}>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-1">
                      First Name *
                    </label>
                    <input
                      type="text"
                      id="firstName"
                      name="firstName"
                      value={shippingFormData.firstName}
                      onChange={handleShippingChange}
                      required
                      className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                  <div>
                    <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 mb-1">
                      Last Name *
                    </label>
                    <input
                      type="text"
                      id="lastName"
                      name="lastName"
                      value={shippingFormData.lastName}
                      onChange={handleShippingChange}
                      required
                      className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                </div>
                
                <div className="mb-4">
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={shippingFormData.email}
                    onChange={handleShippingChange}
                    required
                    className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                
                <div className="mb-4">
                  <label htmlFor="address1" className="block text-sm font-medium text-gray-700 mb-1">
                    Address Line 1 *
                  </label>
                  <input
                    type="text"
                    id="address1"
                    name="address1"
                    value={shippingFormData.address1}
                    onChange={handleShippingChange}
                    required
                    className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                
                <div className="mb-4">
                  <label htmlFor="address2" className="block text-sm font-medium text-gray-700 mb-1">
                    Address Line 2
                  </label>
                  <input
                    type="text"
                    id="address2"
                    name="address2"
                    value={shippingFormData.address2}
                    onChange={handleShippingChange}
                    className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
                  <div>
                    <label htmlFor="city" className="block text-sm font-medium text-gray-700 mb-1">
                      City *
                    </label>
                    <input
                      type="text"
                      id="city"
                      name="city"
                      value={shippingFormData.city}
                      onChange={handleShippingChange}
                      required
                      className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                  <div>
                    <label htmlFor="state" className="block text-sm font-medium text-gray-700 mb-1">
                      State/Province *
                    </label>
                    <input
                      type="text"
                      id="state"
                      name="state"
                      value={shippingFormData.state}
                      onChange={handleShippingChange}
                      required
                      className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                  <div>
                    <label htmlFor="postalCode" className="block text-sm font-medium text-gray-700 mb-1">
                      Postal Code *
                    </label>
                    <input
                      type="text"
                      id="postalCode"
                      name="postalCode"
                      value={shippingFormData.postalCode}
                      onChange={handleShippingChange}
                      required
                      className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label htmlFor="country" className="block text-sm font-medium text-gray-700 mb-1">
                      Country *
                    </label>
                    <select
                      id="country"
                      name="country"
                      value={shippingFormData.country}
                      onChange={handleShippingChange}
                      required
                      className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    >
                      <option value="US">United States</option>
                      <option value="CA">Canada</option>
                      <option value="UK">United Kingdom</option>
                      <option value="AU">Australia</option>
                    </select>
                  </div>
                  <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={shippingFormData.phone}
                      onChange={handleShippingChange}
                      required
                      className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                </div>
                
                <div className="mt-6">
                  <button
                    type="submit"
                    className="btn-primary w-full justify-center"
                    disabled={!isShippingFormValid()}
                  >
                    Proceed to Payment <ChevronRight size={16} className="ml-1" />
                  </button>
                </div>
              </form>
            </div>
          )}
          
          {step === 'payment' && (
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-xl font-medium mb-6">Payment Information</h2>
              
              <form onSubmit={handlePaymentSubmit}>
                <div className="mb-4">
                  <label htmlFor="cardName" className="block text-sm font-medium text-gray-700 mb-1">
                    Name on Card *
                  </label>
                  <input
                    type="text"
                    id="cardName"
                    name="cardName"
                    value={paymentFormData.cardName}
                    onChange={handlePaymentChange}
                    required
                    className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                
                <div className="mb-4">
                  <label htmlFor="cardNumber" className="block text-sm font-medium text-gray-700 mb-1">
                    Card Number *
                  </label>
                  <div className="flex items-center border border-gray-300 rounded-md focus-within:ring-2 focus-within:ring-blue-500 focus-within:border-blue-500">
                    <input
                      type="text"
                      id="cardNumber"
                      name="cardNumber"
                      value={paymentFormData.cardNumber}
                      onChange={handlePaymentChange}
                      required
                      placeholder="XXXX XXXX XXXX XXXX"
                      className="flex-grow p-2 border-none focus:outline-none"
                    />
                    <CreditCard size={20} className="text-gray-400 mr-3" />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <label htmlFor="expDate" className="block text-sm font-medium text-gray-700 mb-1">
                      Expiration Date *
                    </label>
                    <input
                      type="text"
                      id="expDate"
                      name="expDate"
                      value={paymentFormData.expDate}
                      onChange={handlePaymentChange}
                      placeholder="MM/YY"
                      required
                      className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                  <div>
                    <label htmlFor="cvv" className="block text-sm font-medium text-gray-700 mb-1">
                      CVV *
                    </label>
                    <input
                      type="text"
                      id="cvv"
                      name="cvv"
                      value={paymentFormData.cvv}
                      onChange={handlePaymentChange}
                      placeholder="123"
                      required
                      className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                </div>
                
                <div className="flex items-center mt-6 mb-6 bg-blue-50 p-4 rounded-md">
                  <Shield size={20} className="text-blue-600 mr-2" />
                  <p className="text-sm text-blue-800">
                    Your payment information is securely encrypted and processed.
                  </p>
                </div>
                
                <div className="mt-6 flex flex-col sm:flex-row sm:justify-between gap-4">
                  <button
                    type="button"
                    onClick={() => setStep('shipping')}
                    className="btn-outline sm:w-auto"
                  >
                    Back to Shipping
                  </button>
                  <button
                    type="submit"
                    className="btn-primary sm:w-auto"
                    disabled={!isPaymentFormValid()}
                  >
                    Complete Order <ChevronRight size={16} className="ml-1" />
                  </button>
                </div>
              </form>
            </div>
          )}
          
          {step === 'confirmation' && (
            <div className="bg-white rounded-lg shadow-sm p-6 text-center">
              <div className="py-8">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                  </svg>
                </div>
                <h2 className="text-2xl font-display font-bold mb-2">Order Confirmed!</h2>
                <p className="text-gray-600 mb-6">
                  Thank you for your purchase. Your order has been placed and will be processed shortly.
                </p>
                <p className="text-gray-800 mb-2">
                  Order confirmation has been sent to:
                  <span className="font-medium"> {shippingFormData.email}</span>
                </p>
                <p className="text-gray-600 mb-8">
                  You'll receive shipping updates via email.
                </p>
                <button
                  onClick={handlePlaceOrder}
                  className="btn-primary"
                >
                  Continue Shopping
                </button>
              </div>
            </div>
          )}
        </div>
        
        {/* Order Summary */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-sm p-6 sticky top-24">
            <h2 className="text-lg font-medium mb-4">Order Summary</h2>
            
            {step !== 'confirmation' && (
              <ul className="divide-y divide-gray-200 mb-4">
                {cart.map((item) => (
                  <li key={item.id} className="py-4 flex">
                    <img 
                      src={item.images[0]} 
                      alt={item.name} 
                      className="w-16 h-16 object-cover rounded flex-shrink-0"
                    />
                    <div className="ml-4 flex-grow">
                      <h3 className="text-sm font-medium">{item.name}</h3>
                      <p className="text-sm text-gray-500">Qty: {item.quantity}</p>
                      <p className="text-sm font-medium">${(item.price * item.quantity).toFixed(2)}</p>
                    </div>
                  </li>
                ))}
              </ul>
            )}
            
            <div className="space-y-3 border-t pt-4">
              <div className="flex justify-between">
                <span className="text-gray-600">Subtotal</span>
                <span>${totalPrice.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Shipping</span>
                <span>Free</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Tax</span>
                <span>${(totalPrice * 0.08).toFixed(2)}</span>
              </div>
              <div className="border-t pt-3 mt-3 flex justify-between font-medium">
                <span>Total</span>
                <span>${(totalPrice + (totalPrice * 0.08)).toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;