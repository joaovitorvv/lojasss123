import React from 'react';
import HeroBanner from '../components/ui/HeroBanner';
import ProductGrid from '../components/products/ProductGrid';
import FeaturedCategories from '../components/ui/FeaturedCategories';
import Newsletter from '../components/ui/Newsletter';
import { getFeaturedProducts, getNewArrivals } from '../data/products';
import { categories } from '../data/categories';

const HomePage: React.FC = () => {
  const featuredProducts = getFeaturedProducts();
  const newArrivals = getNewArrivals();
  
  const featuredCategories = categories.map(category => ({
    ...category,
    link: `/products?category=${category.name.toLowerCase()}`
  }));

  return (
    <div className="pb-16">
      {/* Hero Banner */}
      <HeroBanner 
        videoUrl="https://player.vimeo.com/external/530215547.sd.mp4?s=d2cd1d8c9785a3c4a8c451d7b8d31c5f7e0efd78&profile_id=164&oauth2_token_id=57447761"
        title="O Futuro da Tecnologia está Aqui"
        subtitle="Descubra produtos inovadores projetados para a vida moderna"
        ctaText="Comprar Novidades"
        ctaLink="/products?category=new"
      />

      {/* Featured Categories */}
      <div className="container-custom py-16">
        <FeaturedCategories categories={featuredCategories} />
      </div>

      {/* New Arrivals */}
      <div className="container-custom">
        <ProductGrid 
          products={newArrivals}
          title="Novidades"
          subtitle="Seja o primeiro a experimentar nossas últimas inovações"
        />
      </div>

      {/* Featured Products Section */}
      <div className="bg-gray-50 py-16 mt-16">
        <div className="container-custom">
          <ProductGrid 
            products={featuredProducts}
            title="Produtos em Destaque"
            subtitle="Seleções especiais do nosso catálogo"
          />
        </div>
      </div>

      {/* Newsletter Section */}
      <Newsletter />
    </div>
  );
};

export default HomePage;